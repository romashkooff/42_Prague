/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: oromashk <oromashk@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 12:17:40 by oromashk          #+#    #+#             */
/*   Updated: 2024/08/10 15:02:58 by oromashk         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_ultimate_ft(int *********nbr)
{
	int		a;

	a = 42;
	*********nbr = a;
}

// int main()
// {
// 	int number;
// 	int *ptr1;


// 	ptr1 = &number;
// 	number = 5;
// 	ft_ultimate_ft(&ptr1);
// 	printf("%d", number);
// }
