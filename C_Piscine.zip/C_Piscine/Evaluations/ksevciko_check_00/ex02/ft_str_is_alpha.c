/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: oromashk <oromashk@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/10 18:27:48 by ksevciko          #+#    #+#             */
/*   Updated: 2024/08/11 15:32:09 by oromashk         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_alpha(char *str)
{
	while (*str != '\0')
	{
		if (*str < 65 || (*str > 90 && *str < 97) || *str > 122)
		{
			return (0);
		}
		str++;
	}
	return (1);
}

int	main(void)
{
	char	str[] = "msjkdhcajL!awp";
	int	num;

	num = ft_str_is_alpha(str);
	printf("%d", num);
}
