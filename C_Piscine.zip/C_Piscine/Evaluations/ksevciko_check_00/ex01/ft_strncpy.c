/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: oromashk <oromashk@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/10 16:58:57 by ksevciko          #+#    #+#             */
/*   Updated: 2024/08/11 15:26:11 by oromashk         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;
	char			*temp;

	temp = dest;
	i = 0;
	while (i < n && *src != '\0')
	{
		*temp = *src;
		i++;
		src++;
		temp++;
	}
	while (i < n)
	{
		*temp = '\0';
		temp++;
		i++;
	}
	return (dest);
}

int	main(void)
{
	char	ptr[10];

	ft_strncpy(ptr, "", 10);
	write(1, ptr, 6);
}