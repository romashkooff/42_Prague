/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: oromashk <oromashk@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 12:46:35 by ksevciko          #+#    #+#             */
/*   Updated: 2024/08/11 15:24:19 by oromashk         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strcpy(char *dest, char *src)
{
	char	*temp;

	temp = dest;
	while (*src != '\0')
	{
		*temp = *src;
		temp++;
		src++;
	}
	return (dest);
}

int	main(void)
{
	char dest[50];
	char *src;

	src = "Hello world";
	src[5] = 'd';
	ft_strcpy(dest, src);
	printf("%s", dest);
}