/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jlager <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/14 21:53:53 by jlager            #+#    #+#             */
/*   Updated: 2024/08/17 19:12:29 by jlager           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcat(char *dest, char *src)
{
	char	*start;

	start = dest;
	while (*start != '\0')
	{
		start++;
	}
	while (*src != '\0')
	{
		*start = *src;
		start++;
		src++;
	}
	*start = '\0';
	return (dest);
}

/*
#include <stdio.h>
int	main(void)
{
	char	before[6] = "happy";
	char	after[6] = "sad";

	printf ("First I have %s and %s\n", before, after);
	ft_strcat(before, after);
	printf ("Than I have %s", before);
}*/
