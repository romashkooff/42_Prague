/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jlager <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/17 22:07:22 by jlager            #+#    #+#             */
/*   Updated: 2024/08/17 22:07:45 by jlager           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	char	*start;

	start = dest;
	while (*start)
	{
		start++;
	}
	while (nb > 0 && *src)
	{
		*start = *src;
		start++;
		src++;
		nb--;
	}
	*start = '\0';
	return (dest);
}

/*
#include <stdio.h>
int	main(void)
{
	char	before[10] = "happy";
	char	after[] = "sad";
	unsigned int	number = '2';

	printf ("First I have %s and %s\n", before, after);
	ft_strncat(before, after, number);
	printf ("Than I have %s", before);
}*/
