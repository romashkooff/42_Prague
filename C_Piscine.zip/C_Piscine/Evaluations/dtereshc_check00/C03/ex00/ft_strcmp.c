/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jlager <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/14 17:57:05 by jlager            #+#    #+#             */
/*   Updated: 2024/08/14 18:17:11 by jlager           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strcmp(char *s1, char *s2)
{
	while (*s1 || *s2)
	{
		if (*s1 != *s2)
		{
			return (*s1 - *s2);
		}
		s1++;
		s2++;
	}
	return (0);
}
/*
#include <stdio.h>
int	main(void)
{
	char	s_1[] = "abcd";
	char	s_2[] = "ABCD";
	
	int	n;
	n = ft_strcmp(s_1, s_2);
	printf("%d", n); 
	return(0);
}
*/
