/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jlager <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/14 21:38:29 by jlager            #+#    #+#             */
/*   Updated: 2024/08/14 21:52:04 by jlager           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;

	i = 0;
	if (n < 1)
		return (0);
	while (s1[i] != '\0' && s2[i] != '\0' && i < n)
	{
		if (s1[i] != s2[i])
			return (s1[i] - s2[i]);
		i++;
	}
	if ((s1[i] == '\0' || s2[i] == '\0') && i < n)
		return (s1[i] - s2[i]);
	if ((s1[i] != '\0' || s2[i] != '\0') && i == n)
		return (0);
	return (0);
}

/*
#include <stdio.h>
int	main(void)
{
	char	s_1[] = "abCd";
	char	s_2[] = "abcd";
	unsigned int	n;
	n = 3;

	int	number;
	number = ft_strncmp(s_1, s_2, n);
	printf("%d", number); 
	return(0);
}*/
