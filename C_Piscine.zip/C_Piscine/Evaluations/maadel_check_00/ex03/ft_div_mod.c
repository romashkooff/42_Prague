/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: maadel <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/12 10:28:49 by maadel            #+#    #+#             */
/*   Updated: 2024/08/13 13:19:15 by maadel           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b;
	*mod = a % b;
}

/*int main ()
{
	int n1;
	int n2;
	int division;
	int modulus;

	n1 = 15;
	n2 = 5;

	ft_div_mod(n1, n2, &division, &modulus);
	printf("%d%d", division, modulus);
}*/
