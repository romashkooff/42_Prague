/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_alphabet.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mdehtiar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/12 13:03:48 by mdehtiar          #+#    #+#             */
/*   Updated: 2024/08/12 13:44:13 by mdehtiar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_alphabet(void)
{
	char	count;

	count = 97;
	while (count <= 122)
	{
		write(1, &count, 1);
		count++;
	}
}

// int	main(void)
//
// {
//	ft_print_alphabet();
//	return (0);
// }
