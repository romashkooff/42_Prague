#!/bin/bash
git log --pretty=format:"%H" | head -n 5

