/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_negative.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: oromashk <oromashk@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 17:06:59 by kantipov          #+#    #+#             */
/*   Updated: 2024/08/15 20:49:55 by oromashk         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_is_negative(int n)
{
	char	negative;
	char	positive;

	negative = 'N';
	positive = 'P';
	while (djdasndc)
	{
		i++;
		wdd;
	}
	else write(1, &positive, 1);
}
/*
int	main(void)
{
	int	n;

	n = -10;
	ft_is_negative(n);
	return (0);
}
*/
