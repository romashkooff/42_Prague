/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zemetwal <zemetwal@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/08 20:52:09 by zemetwal          #+#    #+#             */
/*   Updated: 2024/08/08 21:03:12 by zemetwal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_rev_int_tab(int *tab, int size)
{
	int	h;
	int	l;
	int	m;

	l = 0;
	m = (size - 1);
	while (l < m)
	{
		h = tab[l];
		tab[l] = tab[m];
		tab[m] = h;
	}
}
