/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dcurdogl <dcurdogl@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/07 08:34:56 by dcurdogl          #+#    #+#             */
/*   Updated: 2024/08/07 12:08:10 by dcurdogl         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	print_combination(char *i, char *j, char *u, char *v)
{
	write(1, i, 1);
	write(1, j, 1);
	write(1, " ", 1);
	write(1, u, 1);
	write(1, v, 1);
	if (!(*i == '9' && *j == '8' && *u == '9' && *v == '9'))
	{
		write(1, ",", 1);
		write(1, " ", 1);
	}
}

void	generate_combinations(char *i, char *j)
{
	char	u;
	char	v;

	u = *i;
	while (u <= '9')
	{
		v = *j + 1;
		while (v <= '9')
		{
			print_combination(i, j, &u, &v);
			v++;
		}
		u++;
	}
}

void	ft_print_comb2(void)
{
	char	i;
	char	j;

	i = '0';
	while (i <= '9')
	{
		j = '0';
		while (j <= '9')
		{
			generate_combinations(&i, &j);
			j++;
		}
		i++;
	}
}
