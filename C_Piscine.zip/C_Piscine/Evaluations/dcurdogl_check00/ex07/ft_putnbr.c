/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dcurdogl <dcurdogl@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/07 11:22:09 by dcurdogl          #+#    #+#             */
/*   Updated: 2024/08/07 12:19:42 by dcurdogl         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putnbr(int nb)
{
	int		pow;
	int		nb_copy;
	int		n;
	char	c;

	pow = 1;
	nb_copy = nb;
	while (nb_copy > 9)
	{
		pow *= 10;
		nb_copy /= 10;
	}
	while (nb > 0)
	{
		n = nb / pow;
		c = n + '0';
		write(1, &c, 1);
		nb -= n * pow;
		pow /= 10;
	}
}
