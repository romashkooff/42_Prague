/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dcurdogl <dcurdogl@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/07 08:34:44 by dcurdogl          #+#    #+#             */
/*   Updated: 2024/08/07 14:30:44 by dcurdogl         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	print_comb(char *first_num, char i, char j, char u)
{
	if (*first_num == 'F')
	{
		write(1, ",", 1);
		write(1, " ", 1);
	}
	write(1, &i, 1);
	write(1, &j, 1);
	write(1, &u, 1);
	*first_num = 'F';
}

void	ft_print_comb(void)
{
	char	i;
	char	j;
	char	u;
	char	first_num;

	first_num = 'T';
	i = '0';
	while (i <= '9')
	{
		j = i + 1;
		while (j <= '9')
		{
			u = j + 1;
			while (u <= '9')
			{
				print_comb(&first_num, i, j, u);
				u++;
			}
			j++;
		}
		i++;
	}
}
