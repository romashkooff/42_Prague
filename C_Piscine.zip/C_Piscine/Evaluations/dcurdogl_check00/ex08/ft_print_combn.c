/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dcurdogl <dcurdogl@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/07 12:23:49 by dcurdogl          #+#    #+#             */
/*   Updated: 2024/08/07 14:25:31 by dcurdogl         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	print_digits(char *digs, int n)
{
	int	i;

	i = 0;
	while (i < n)
	{
		write(1, &digs[i], 1);
		i++;
	}
	if (digs[0] != '9' - n + 1)
	{
		write(1, ",", 1);
		write(1, " ", 1);
	}
}

void	generate_digs(char *digs, int i, int n, char last)
{
	char	c;

	c = last;
	if (n == i)
	{
		print_digits(digs, n);
	}
	else
	{
		while (c <= '9')
		{
			digs[i] = c;
			generate_digs(digs, i + 1, n, c + 1);
			c++;
		}
		n = n - 1;
	}
}

void	ft_print_combn(int n)
{
	char	digs[10];

	if (n > 0 && n < 10)
	{
		generate_digs(digs, 0, n, '0');
	}
	else
	{
		write(1, "E", 1);
	}
}
