/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hlyshchu <hlyshchu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/21 07:37:42 by hlyshchu          #+#    #+#             */
/*   Updated: 2024/08/21 08:10:20 by hlyshchu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <fcntl.h>
#include <unistd.h>

#define ERR_CANNOT_READ_FILE "Cannot read file.\n"
#define ERR_FILE_NAME_MISS "File name missing.\n"
#define ERR_TOO_MANY_ARGS "Too many arguments.\n"
#define BUFFER 4096

int	ft_strlen(char *str)
{
	int	counter;

	counter = 0;
	while (str[counter])
	{
		counter++;
	}
	return (counter);
}

int	ft_args_control(int argc)
{
	if (argc == 1)
	{
		write(2, ERR_FILE_NAME_MISS, ft_strlen(ERR_FILE_NAME_MISS));
		return (0);
	}
	if (argc > 2)
	{
		write(2, ERR_TOO_MANY_ARGS, ft_strlen(ERR_TOO_MANY_ARGS));
		return (0);
	}
	return (1);
}

int	main(int argc, char **argv)
{
	int		file;
	ssize_t	bytes_read;
	char	buffer[BUFFER];

	if (!ft_args_control(argc))
		return (1);
	file = open(argv[1], O_RDONLY);
	if (file == -1)
	{
		write(2, ERR_CANNOT_READ_FILE, ft_strlen(ERR_CANNOT_READ_FILE));
		return (1);
	}
	bytes_read = read(file, buffer, BUFFER);
	while (bytes_read > 0)
	{
		write(1, buffer, bytes_read);
		bytes_read = read(file, buffer, BUFFER);
	}
	if (bytes_read == -1)
		write(2, ERR_CANNOT_READ_FILE, ft_strlen(ERR_CANNOT_READ_FILE));
	close(file);
	return (0);
}
