/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hlyshchu <hlyshchu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/21 09:19:16 by hlyshchu          #+#    #+#             */
/*   Updated: 2024/08/22 17:50:10 by hlyshchu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <errno.h>
#include <fcntl.h>
#include <libgen.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define BUFFER 30720

int	ft_strlen(char *str)
{
	int	counter;

	counter = 0;
	while (str[counter])
	{
		counter++;
	}
	return (counter);
}

void	ft_print_error_file(char *program_name, char *file_name)
{
	char	*error_msg;

	error_msg = strerror(errno);
	write(2, program_name, ft_strlen(program_name));
	write(2, ": ", 2);
	write(2, file_name, ft_strlen(file_name));
	write(2, ": ", 2);
	write(2, error_msg, ft_strlen(error_msg));
	write(2, "\n", 1);
}

void	ft_cat(int file)
{
	char	buffer[BUFFER];
	ssize_t	bytes_read;

	bytes_read = read(file, buffer, BUFFER);
	while (bytes_read > 0)
	{
		write(1, buffer, bytes_read);
		bytes_read = read(file, buffer, BUFFER);
	}
}

int	main(int argc, char **argv)
{
	int	file;
	int	i;

	if (argc < 2)
		ft_cat(STDIN_FILENO);
	else
	{
		i = 1;
		while (i < argc)
		{
			file = open(argv[i], O_RDONLY);
			if (file == -1)
			{
				ft_print_error_file(argv[0], argv[i]);
			}
			else
			{
				ft_cat(file);
				close(file);
			}
			i++;
		}
	}
	return (0);
}
