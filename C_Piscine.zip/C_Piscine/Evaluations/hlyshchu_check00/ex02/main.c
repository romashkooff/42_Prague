/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hlyshchu <hlyshchu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/22 11:23:27 by hlyshchu          #+#    #+#             */
/*   Updated: 2024/08/22 19:56:05 by hlyshchu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int	ft_if_file_err_main_check(char *file_name, char **argv)
{
	int	file;

	file = open(file_name, O_RDONLY);
	if (file == -1)
	{
		ft_print_error_file(argv[0], file_name);
		return (0);
	}
	close(file);
	return (1);
}

int	ft_argc_control(int argc, char **argv)
{
	int	bytes_to_print;

	if (argc < 3)
	{
		ft_print_error_2_args(argv[0]);
		return (0);
	}
	else if (argc == 3)
	{
		bytes_to_print = ft_str_to_int(argv[2]);
		if (bytes_to_print == 0)
			return (0);
		else if (bytes_to_print != -1 && bytes_to_print != 0)
		{
			ft_read_from_stdn();
			return (0);
		}
		else
		{
			ft_print_error_not_bytes(argv[0], argv[2]);
			return (0);
		}
	}
	return (1);
}

int	ft_process_single_file(char *filename, int bytes_to_print, char **argv)
{
	if (!ft_tail(filename, bytes_to_print, argv))
		return (1);
	return (0);
}

int	ft_process_multiple_files(int argc, char **argv, int bytes_to_print)
{
	int	i;
	int	first_file_processed;

	first_file_processed = 0;
	i = 3;
	while (i < argc)
	{
		if (!(ft_if_file_err_main_check(argv[i], argv)))
		{
			i++;
			continue ;
		}
		if (first_file_processed)
			write(1, "\n", 1);
		ft_print_tail_header(argv[i]);
		ft_tail(argv[i], bytes_to_print, argv);
		first_file_processed = 1;
		i++;
	}
	return (0);
}

int	main(int argc, char **argv)
{
	int	bytes_to_print;

	if (!ft_argc_control(argc, argv))
		return (1);
	bytes_to_print = ft_str_to_int(argv[2]);
	if (bytes_to_print == 0)
		return (0);
	if (bytes_to_print == -1)
	{
		ft_print_error_not_bytes(argv[0], argv[2]);
		return (1);
	}
	if (argc == 4)
	{
		ft_process_single_file(argv[3], bytes_to_print, argv);
		return (0);
	}
	else
	{
		ft_process_multiple_files(argc, argv, bytes_to_print);
		return (0);
	}
}

// int	main(int argc, char **argv)
// {
// 	int	bytes_to_print;
// 	int	i;

// 	if (!ft_argc_control(argc, argv))
// 		return (1);
// 	bytes_to_print = ft_str_to_int(argv[2]);
// 	if (bytes_to_print == -1)
// 	{
// 		ft_print_error_not_bytes(argv[0], argv[2]);
// 		return (1);
// 	}
// 	if (argc == 4)
// 	{
// 		if (!ft_tail(argv[3], bytes_to_print, argv))
// 			return (1);
// 	}
// 	else
// 	{
// 		i = 3;
// 		while (i < argc)
// 		{
// 			if (!(ft_if_file_err_main_check(argv[i], argv)))
// 			{
// 				i++;
// 				continue ;
// 			}
// 			if (i + 1 < argc && i != 3)
// 				write(1, "\n", 1);
// 			ft_print_tail_header(argv[i]);
// 			ft_tail(argv[i], bytes_to_print, argv);
// 			i++;
// 		}
// 	}
// 	return (0);
// }
