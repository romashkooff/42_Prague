/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tail.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hlyshchu <hlyshchu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/22 15:02:26 by hlyshchu          #+#    #+#             */
/*   Updated: 2024/08/22 19:42:48 by hlyshchu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int	ft_skip_bytes(int file, int total_bytes, int bytes_to_print)
{
	char	buffer[1];
	ssize_t	bytes_read;

	while (total_bytes > bytes_to_print)
	{
		bytes_read = read(file, buffer, 1);
		if (bytes_read <= 0)
			return (0);
		total_bytes--;
	}
	return (1);
}

int	ft_print_remaining(int file)
{
	char	buffer[1];
	ssize_t	bytes_read;

	bytes_read = read(file, buffer, 1);
	while (bytes_read > 0)
	{
		write(1, buffer, 1);
		bytes_read = read(file, buffer, 1);
	}
	if (bytes_read < 0)
		return (0);
	return (1);
}

int	ft_tail(char *filename, int bytes_to_print, char **argv)
{
	int	file;
	int	total_bytes;

	total_bytes = ft_count_bytes(filename, argv);
	if (total_bytes < 0)
		return (0);
	file = open(filename, O_RDONLY);
	if (!ft_if_file_err(file, filename, argv))
		return (0);
	if (!ft_skip_bytes(file, total_bytes, bytes_to_print))
	{
		ft_print_error_cannot_read(argv[0], filename);
		close(file);
		return (0);
	}
	if (!ft_print_remaining(file))
	{
		ft_print_error_cannot_read(argv[0], filename);
		close(file);
		return (0);
	}
	close(file);
	return (1);
}
