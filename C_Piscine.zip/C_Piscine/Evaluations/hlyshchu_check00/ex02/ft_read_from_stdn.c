/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_read_from_stdn.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hlyshchu <hlyshchu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/22 14:45:16 by hlyshchu          #+#    #+#             */
/*   Updated: 2024/08/22 15:26:26 by hlyshchu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

void	ft_read_from_stdn(void)
{
	int	buffer[BUFFER];
	int	bytes_read;

	bytes_read = read(0, buffer, BUFFER);
	while (bytes_read > 0)
	{
		bytes_read = read(0, buffer, BUFFER);
	}
}
