/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_count_bytes.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hlyshchu <hlyshchu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/22 11:46:15 by hlyshchu          #+#    #+#             */
/*   Updated: 2024/08/22 18:04:43 by hlyshchu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int	ft_count_bytes(char *filename, char **argv)
{
	int		count;
	char	buffer[BUFFER];
	ssize_t	bytes_read;
	int		file;

	count = 0;
	file = open(filename, O_RDONLY);
	if (!ft_if_file_err(file, filename, argv))
		return (-1);
	bytes_read = read(file, buffer, BUFFER);
	while (bytes_read > 0)
	{
		count += bytes_read;
		bytes_read = read(file, buffer, BUFFER);
		if (bytes_read == -1)
		{
			ft_print_error_cannot_read(argv[0], filename);
			close(file);
			return (-1);
		}
	}
	close(file);
	return (count);
}
