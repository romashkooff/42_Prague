/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hlyshchu <hlyshchu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/22 11:24:11 by hlyshchu          #+#    #+#             */
/*   Updated: 2024/08/22 17:46:42 by hlyshchu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H
# define BUFFER 1
# define ERROR_INPUT "Usage: ./ft_tail -c <number_of_bytes> <filename>\n"
# include <errno.h>
# include <fcntl.h>
# include <libgen.h>
# include <stdio.h>
# include <string.h>
# include <unistd.h>

int		ft_strlen(char *str);
void	ft_print_error_2_args(char *program_name);
void	ft_print_error_file(char *program_name, char *file_name);
void	ft_print_error_not_bytes(char *program_name, char *bytes);
void	ft_print_error_cannot_read(char *program_name, char *file_name);
int		ft_count_bytes(char *filename, char **argv);
int		ft_if_file_err(int file, char *file_name, char **argv);
int		ft_str_to_int(char *str);
void	ft_read_from_stdn(void);
int		ft_if_file_err(int file, char *file_name, char **argv);
int		ft_skip_bytes(int file, int total_bytes, int bytes_to_print);
int		ft_print_remaining(int file);
int		ft_tail(char *filename, int bytes_to_print, char **argv);
void	ft_print_tail_header(char *file_name);
#endif
