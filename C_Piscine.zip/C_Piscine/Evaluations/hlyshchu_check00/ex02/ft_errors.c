/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_errors.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hlyshchu <hlyshchu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/22 11:42:41 by hlyshchu          #+#    #+#             */
/*   Updated: 2024/08/22 18:14:53 by hlyshchu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

void	ft_print_error_file(char *program_name, char *file_name)
{
	char	*error_msg;

	error_msg = strerror(errno);
	write(2, program_name, ft_strlen(program_name));
	write(2, ": ", 2);
	write(2, "cannot open '", ft_strlen("cannot open '"));
	write(2, file_name, ft_strlen(file_name));
	write(2, "' for reading", ft_strlen("' for reading"));
	write(2, ": ", 2);
	write(2, error_msg, ft_strlen(error_msg));
	write(2, "\n", 1);
}

void	ft_print_error_2_args(char *program_name)
{
	write(2, program_name, ft_strlen(program_name));
	write(2, ": option requires an argument -- 'c'\n",
		ft_strlen(": option requires an argument -- 'c'\n"));
	write(2, "Try 'tail --help' for more information.",
		ft_strlen("Try 'tail --help' for more information."));
	write(2, "\n", 1);
}

void	ft_print_error_not_bytes(char *program_name, char *bytes)
{
	write(2, program_name, ft_strlen(program_name));
	write(2, ": invalid number of bytes: ",
		ft_strlen(": invalid number of bytes: "));
	write(2, "‘", 3);
	write(2, bytes, ft_strlen(bytes));
	write(2, "’", 3);
	write(2, "\n", 1);
}

void	ft_print_error_cannot_read(char *program_name, char *file_name)
{
	char	*error_message;

	error_message = strerror(errno);
	write(2, program_name, ft_strlen(program_name));
	write(2, ": cannot read '", ft_strlen(": cannot read '"));
	write(2, file_name, ft_strlen(file_name));
	write(2, "': ", ft_strlen("': "));
	write(2, error_message, ft_strlen(error_message));
	write(2, "\n", 1);
}

int	ft_if_file_err(int file, char *file_name, char **argv)
{
	if (file == -1)
	{
		ft_print_error_file(argv[0], file_name);
		return (0);
	}
	return (1);
}
