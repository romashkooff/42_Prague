/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tail_header.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hlyshchu <hlyshchu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/21 18:18:43 by hlyshchu          #+#    #+#             */
/*   Updated: 2024/08/22 15:27:00 by hlyshchu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

void	ft_print_tail_header(char *file_name)
{
	write(1, "==> ", ft_strlen("==> "));
	write(1, basename(file_name), ft_strlen(basename(file_name)));
	write(1, " <==", ft_strlen(" <=="));
	write(1, "\n", 1);
}
