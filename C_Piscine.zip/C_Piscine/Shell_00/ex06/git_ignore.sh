git ls-files -i --exclude-standart -o
