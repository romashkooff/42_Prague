// candidates_init.h
#ifndef CANDIDATES_INIT_H
#define CANDIDATES_INIT_H

#define N 5

void initialize_candidates(int candidates[N][N][N]);
void print_candidates(int candidates[N][N][N]);

#endif
